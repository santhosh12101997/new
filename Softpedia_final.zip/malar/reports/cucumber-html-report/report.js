$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/SANTHOSH KUMAR/Desktop/Github_malar_project/githubdemo-master/malar/src/main/resources/feature/TestScenario.feature");
formatter.feature({
  "line": 2,
  "name": "SoftPedia Application",
  "description": "",
  "id": "softpedia-application",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@softpedia"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "",
  "description": "To Create a account",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@tc_01_reg"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "launch and registration",
  "keyword": "Given "
});
formatter.match({
  "location": "Definition_Register.launch_and_registration()"
});
formatter.result({
  "duration": 298169163738,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "",
  "description": "Login account",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 10,
      "name": "@tc_02_login"
    }
  ]
});
formatter.step({
  "line": 14,
  "name": "launch application",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "click the user icon and enter username password",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "click login button",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_Login.launch_application()"
});
formatter.result({
  "duration": 20521097878,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Login.click_the_user_icon_and_enter_username_password()"
});
formatter.result({
  "duration": 3423270760,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Login.click_login_button()"
});
formatter.result({
  "duration": 4209671917,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "",
  "description": "Search for application",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 18,
      "name": "@tc_03_search"
    }
  ]
});
formatter.step({
  "line": 22,
  "name": "launch the softpedia application",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "Enter the word for search",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "Click go button",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "download the application",
  "keyword": "Then "
});
formatter.step({
  "line": 26,
  "name": "Check file is exist or not",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_Search.launch_the_softpedia_application()"
});
formatter.result({
  "duration": 9152629598,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Search.enter_the_word_for_search()"
});
formatter.result({
  "duration": 202442171,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Search.click_go_button()"
});
formatter.result({
  "duration": 10292596267,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Search.download_the_application()"
});
formatter.result({
  "duration": 41647260927,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Search.Check_file_is_exist_or_not()"
});
formatter.result({
  "duration": 3348983691,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "",
  "description": "Send feedback through contact us",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 28,
      "name": "@tc_04_contactus"
    }
  ]
});
formatter.step({
  "line": 32,
  "name": "launch the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "click i named icon and contact us",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "click radio button from the list",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "enter a message and mail id",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "click send button",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_ContactUs.launch_the_browser()"
});
formatter.result({
  "duration": 19965012487,
  "status": "passed"
});
formatter.match({
  "location": "Definition_ContactUs.click_i_named_icon_and_contact_us()"
});
formatter.result({
  "duration": 3269130016,
  "status": "passed"
});
formatter.match({
  "location": "Definition_ContactUs.click_radio_button_from_the_list()"
});
formatter.result({
  "duration": 228723004,
  "status": "passed"
});
formatter.match({
  "location": "Definition_ContactUs.enter_a_message_and_mail_id()"
});
formatter.result({
  "duration": 712224053,
  "status": "passed"
});
formatter.match({
  "location": "Definition_ContactUs.click_send_button()"
});
formatter.result({
  "duration": 4416672450,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "",
  "description": "Alert Handling in submit Application",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 37,
      "name": "@tc_05_SubmitApplication"
    }
  ]
});
formatter.step({
  "line": 41,
  "name": "launch browser",
  "keyword": "Given "
});
formatter.step({
  "line": 42,
  "name": "click i named icon and submit application",
  "keyword": "Then "
});
formatter.step({
  "line": 43,
  "name": "click submit form",
  "keyword": "Then "
});
formatter.step({
  "line": 44,
  "name": "Handle the alert message",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_SubmitApplication.launch_browser()"
});
formatter.result({
  "duration": 18244845636,
  "status": "passed"
});
formatter.match({
  "location": "Definition_SubmitApplication.click_i_named_icon_and_submit_application()"
});
formatter.result({
  "duration": 4229207333,
  "status": "passed"
});
formatter.match({
  "location": "Definition_SubmitApplication.click_submit_form()"
});
formatter.result({
  "duration": 239994526,
  "status": "passed"
});
formatter.match({
  "location": "Definition_SubmitApplication.handle_the_alert_message()"
});
formatter.result({
  "duration": 5263602019,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "",
  "description": "Finding the phone based on requirements",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 46,
      "name": "@tc_06_PhoneFinder"
    }
  ]
});
formatter.step({
  "line": 50,
  "name": "launch the Softpedia application in browser",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "scroll down to the page and click on find your phone",
  "keyword": "Then "
});
formatter.step({
  "line": 52,
  "name": "select brand flatform battery and availability",
  "keyword": "Then "
});
formatter.step({
  "line": 53,
  "name": "click go button",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_phoneFinder.launch_the_Softpedia_application_in_browser()"
});
formatter.result({
  "duration": 16166745514,
  "status": "passed"
});
formatter.match({
  "location": "Definition_phoneFinder.scroll_down_to_the_page_and_click_on_find_your_phone()"
});
formatter.result({
  "duration": 2329736136,
  "status": "passed"
});
formatter.match({
  "location": "Definition_phoneFinder.select_brand_flatform_battery_and_availability()"
});
formatter.result({
  "duration": 2527038360,
  "status": "passed"
});
formatter.match({
  "location": "Definition_phoneFinder.click_go_button()"
});
formatter.result({
  "duration": 336272867,
  "status": "passed"
});
formatter.scenario({
  "line": 56,
  "name": "",
  "description": "checking price claim not accepting",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 55,
      "name": "@tc_07_PrizeClaim"
    }
  ]
});
formatter.step({
  "line": 59,
  "name": "launch the softpedia website in browser",
  "keyword": "Given "
});
formatter.step({
  "line": 60,
  "name": "click i named icon and Discounts and Giveaways",
  "keyword": "Then "
});
formatter.step({
  "line": 61,
  "name": "click submit \u0026 get license button",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_PrizeClaim.launch_the_softpedia_website_in_browser()"
});
formatter.result({
  "duration": 18482853485,
  "status": "passed"
});
formatter.match({
  "location": "Definition_PrizeClaim.click_i_named_icon_and_Discounts_and_Giveaways()"
});
formatter.result({
  "duration": 6945277182,
  "status": "passed"
});
formatter.match({
  "location": "Definition_PrizeClaim.click_submit_get_license_button()"
});
formatter.result({
  "duration": 5572242232,
  "status": "passed"
});
formatter.scenario({
  "line": 64,
  "name": "",
  "description": "checking the availability of games",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 63,
      "name": "@tc_08_Games"
    }
  ]
});
formatter.step({
  "line": 67,
  "name": "launch the softpedia website",
  "keyword": "Given "
});
formatter.step({
  "line": 68,
  "name": "click games tab",
  "keyword": "Then "
});
formatter.step({
  "line": 69,
  "name": "click side bar",
  "keyword": "Then "
});
formatter.step({
  "line": 70,
  "name": "click the required game",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_Games.launch_the_softpedia_website()"
});
formatter.result({
  "duration": 21163490589,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Games.click_games_tab()"
});
formatter.result({
  "duration": 31126314554,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Games.click_side_bar()"
});
formatter.result({
  "duration": 261404212,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Games.click_the_required_game()"
});
formatter.result({
  "duration": 694722720,
  "error_message": "org.openqa.selenium.StaleElementReferenceException: stale element reference: element is not attached to the page document\n  (Session info: chrome\u003d80.0.3987.149)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/stale_element_reference.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027SANTHOSH\u0027, ip: \u0027192.168.43.152\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.3\u0027, java.version: \u002713.0.2\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 80.0.3987.149, chrome: {chromedriverVersion: 79.0.3945.36 (3582db32b3389..., userDataDir: C:\\Users\\SANTHO~1\\AppData\\L...}, goog:chromeOptions: {debuggerAddress: localhost:51011}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: ede586040bdeaa929c955c11c301b2b9\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:500)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:481)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat com.Pages.Page_Games.SelectGame(Page_Games.java:43)\r\n\tat com.StepDefinition.Definition_Games.click_the_required_game(Definition_Games.java:30)\r\n\tat ✽.And click the required game(C:/Users/SANTHOSH KUMAR/Desktop/Github_malar_project/githubdemo-master/malar/src/main/resources/feature/TestScenario.feature:70)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 73,
  "name": "",
  "description": "Softpedia News Calendar",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 72,
      "name": "@tc_09_Calender"
    }
  ]
});
formatter.step({
  "line": 76,
  "name": "Launch the browser for calendar",
  "keyword": "Given "
});
formatter.step({
  "line": 77,
  "name": "Select month and year",
  "keyword": "Then "
});
formatter.step({
  "line": 78,
  "name": "Select the date",
  "keyword": "Then "
});
formatter.step({
  "line": 79,
  "name": "Scroll and click any news",
  "keyword": "And "
});
formatter.match({
  "location": "Definition_Calendar.launch_the_browser_for_calendar()"
});
formatter.result({
  "duration": 10698574870,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Calendar.select_month_and_year()"
});
formatter.result({
  "duration": 3828578830,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Calendar.select_the_date()"
});
formatter.result({
  "duration": 9913002595,
  "status": "passed"
});
formatter.match({
  "location": "Definition_Calendar.scroll_and_click_any_news()"
});
formatter.result({
  "duration": 11768188238,
  "status": "passed"
});
formatter.scenario({
  "line": 82,
  "name": "",
  "description": "Navigation of the page",
  "id": "softpedia-application;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 81,
      "name": "@tc_10_NextPage"
    }
  ]
});
formatter.step({
  "line": 85,
  "name": "Launch the application for nextpage",
  "keyword": "Given "
});
formatter.step({
  "line": 86,
  "name": "Scroll Down and click next page",
  "keyword": "Then "
});
formatter.match({
  "location": "Definition_NextPage.launch_the_application_for_nextpage()"
});
formatter.result({
  "duration": 25328220592,
  "status": "passed"
});
formatter.match({
  "location": "Definition_NextPage.scroll_Down_and_click_next_page()"
});
formatter.result({
  "duration": 12036484974,
  "status": "passed"
});
});
package com.Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Page_NextPage 
{
	WebDriver driver;
	By nextpage=By.xpath("/html/body/div/div[2]/div[10]/div[9]/div[22]/div[8]/div/a[11]");
	By previouspage=By.xpath("//*[@id=\"sjmp\"]/div[9]/div[22]/div[8]/div/a[1]");
	
	//To Launch the Softpedia Website in the Browser
	public void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SANTHOSH KUMAR\\Desktop\\Github_malar_project\\githubdemo-master\\malar\\src\\test\\resources\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://linux.softpedia.com/");
	}
	
	//To scroll to bottom of the page and click nextpage and previous page
	public void Scroll_clicknext()
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0, document.body.scrollHeight)");	
		driver.findElement(nextpage).click();
		js.executeScript("window.scrollBy(0, document.body.scrollHeight)");	
		driver.findElement(previouspage).click();
	}
	
	//To close the Browser 
	public void Quit()
	{
		driver.close();
	}
}



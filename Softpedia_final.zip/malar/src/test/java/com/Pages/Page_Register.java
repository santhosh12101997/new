package com.Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.ExcelUtility.Excel_data;

public class Page_Register 
{
	WebDriver driver;
	WebElement Register;
	Excel_data ed = new Excel_data();
	
	//To register an account using for loop 
	public void registration() throws IOException
	{
		for(int i=1;i<=3;i++)
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\SANTHOSH KUMAR\\Desktop\\Github_malar_project\\githubdemo-master\\malar\\src\\test\\resources\\Driver\\chromedriver.exe");
		
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			driver.get("https://www.softpedia.com/");
		
			Register=driver.findElement(By.xpath("//*[@id=\"navicos\"]/li[3]"));
			Register.click();
			System.out.println("click the user icon");
			Register=driver.findElement(By.xpath("//*[@id=\"spovl1\"]/div/div/div[1]/a[3]"));
			Register.click();
			System.out.println("click on register now button");
		
		
			driver.findElement(By.id("reguser")).sendKeys(ed.excel_username(i));
			driver.findElement(By.id("regmail")).sendKeys(ed.Email(i));
			driver.findElement(By.id("regpass1")).sendKeys(ed.excel_password(i));
			driver.findElement(By.id("regpass2")).sendKeys(ed.excel_repassword(i));
			driver.findElement(By.xpath("//*[@id=\"regbtn\"]")).click();
			driver.close();
		}
	}
}
	